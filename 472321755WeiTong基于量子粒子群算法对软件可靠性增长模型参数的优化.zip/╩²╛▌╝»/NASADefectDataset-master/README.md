# NASADefectDataset

A backup site of NASA defect datasets that were originally published by [Shepperd et al., (2014)](http://nasa-softwaredefectdatasets.wikispaces.com/).

##### Maintained by Chakkrit (Kla) Tantithamthavorn
##### Contact: kla@chakkrit.com
